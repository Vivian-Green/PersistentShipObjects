## 0.0.4
 - this is an example text 1
 - this is another example text
 - balls
 
## 0.0.2
### the "ohgod I actually have users" update
- OHGOD I woke up to 83 downloads when I was just testing thunderstore things- I will get this into a runnable state.
- improved logging, renamed mod folder to spell persistent correctly (was right everywhere else-)
- still very broken but progress is being made

## 0.0.0
- initial commit, untested, literally just built, & definitely broken