## 0.0.8
 - Saved placeableShipObject transforms are now actually loaded! Sometimes!
 - see known bugs list in README.md

## 0.0.7
 - rewrote most of the base plugin
 - extracted* patches to patches folder *just ShipBuildModeManagerPatch.cs
 - rewrote most of the code to fetch placeableShipObjects' transforms
 - removed transform wrapper class
 - fixed another typo- they're very persistant

## 0.0.6
 - moved to netstandard 2.1 with many headaches
 - removed config's old usage bc that isn't going to work
 - like half the code is commented out but it runs now? Like it doesn't work but it runs

## 0.0.5
 - added post-build script for automatic exporting
 - messed with attributes until BepInEx actually noticed the mod

## 0.0.3
 - added export script that only took 6hrs to write and.. actually I think that one was worth it pog

## 0.0.2
- OHGOD I woke up to 83 downloads when I was just testing thunderstore things- I will get this into a runnable state.
- improved logging, renamed mod folder to spell persistent correctly (was right everywhere else-)
- still very broken but progress is being made

## 0.0.0
- initial commit, untested, literally just built, & definitely broken