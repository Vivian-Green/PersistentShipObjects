
# PersistentShipObjects
 
Lethal company mod to keep ya things where ya left 'em. 

## planned changes:
 - remove the billion debug prints
 - lots of testing
 - storing transforms for the grabbableObjects that spawn on the ship
 - sweeping the caffeing off of my code after finally making it work decently

## known bugs:
 - Somehow, I haven't found any new ones since fixing the last two. Please report issues on github with as much context as you can. Your LogOutput.log, description of the problem, how it can be reproduced, etc. would be very helpful <3
 - on that note, if anyone wants to poke through my code- go for it. It's still very rough for now.
 
