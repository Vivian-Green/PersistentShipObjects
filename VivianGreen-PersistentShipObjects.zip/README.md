# PersistentShipObjects
 
lethal company mod to keep ya things where ya left 'em


Known issues: the dev
